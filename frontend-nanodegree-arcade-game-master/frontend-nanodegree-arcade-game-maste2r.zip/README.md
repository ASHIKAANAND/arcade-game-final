#frontend-nanodegree-arcade-game
This is a simple game using the object oriented javascript.The objective of the game is to safely cross the player.

##Player
*The player moves _up,down,right, and left_ depending on the key press.The player can't touch the enemies,if so they are put back to their starting point.

##Enemies
*They move across the canvas, at a speed determined at  `this.speed =  Math.random()*300;`.
*determined by **Enemy** class
## instalations
*please install sublime text,**google chrome**
*this application has _app.js, engine.js, index.html, images file,REad me file_.


 ##playing application
 *To succesfully run program, the enemies are required to move across the screen using enemy class,and player uses an Player class
*Run the Html file in chrome.
*move the player using up,down,right,left,keys.



===============================

Students should use this [rubric](https://review.udacity.com/#!/projects/2696458597/rubric) for self-checking their submission. Make sure the functions you write are **object-oriented** - either class functions (like Player and Enemy) or class prototype functions such as Enemy.prototype.checkCollisions, and that the keyword 'this' is used appropriately within your class and class prototype functions to refer to the object the function is called upon. Also be sure that the **readme.md** file is updated with your instructions on both how to 1. Run and 2. Play your arcade game.

For detailed instructions on how to get started, check out this [guide](https://docs.google.com/document/d/1v01aScPjSWCCWQLIpFqvg3-vXLH2e8_SZQKC8jNO0Dc/pub?embedded=true).
